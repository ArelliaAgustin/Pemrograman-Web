<header class="header_area">
	<div class="main_menu">
		<nav class="navbar navbar-expand-lg navbar-light">
			<div class="container">
				<!-- Brand and toggle get grouped for better mobile display -->
				<a class="navbar-brand logo_h" href="index.php"><img src="img/logo2.png" alt=""></a>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
					aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse offset" id="navbarSupportedContent">
					<ul class="nav navbar-nav menu_nav justify-content-end">
						<li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">
							<a class="nav-link" href="index.php">Home</a>
						</li>
						<li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'about.php' ? 'active' : ''; ?>">
							<a class="nav-link" href="about.php">About</a>
						</li>
						<li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'skills.php' ? 'active' : ''; ?>">
							<a class="nav-link" href="skills.php">Skills</a>
						</li>
						<li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'hobbies.php' ? 'active' : ''; ?>">
							<a class="nav-link" href="hobbies.php">Hobbies</a>
						</li>
						<li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'contact.php' ? 'active' : ''; ?>">
							<a class="nav-link" href="contact.php">Contact</a>
						</li>
					</ul>
				</div>
			</div>
		</nav>
	</div>
</header>
