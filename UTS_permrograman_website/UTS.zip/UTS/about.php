<?php
// MySQL connection
$servername = "localhost";
$username = "root"; // Adjust this with your MySQL username
$password = ""; // Adjust this with your MySQL password
$dbname = "db_utspemweb"; // Adjust with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch biodata from the database
$sql = "SELECT * FROM biodata WHERE id = 1"; // Adjust the ID if necessary
$result = $conn->query($sql);

$biodata = $result->fetch_assoc();
?>

<!doctype html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="icon" href="img/favicon2.png" type="image/png">
	<title>About Us</title>
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="vendors/linericon/style.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">
	<link rel="stylesheet" href="css/magnific-popup.css">
	<link rel="stylesheet" href="vendors/nice-select/css/nice-select.css">
	<!-- main css -->
	<link rel="stylesheet" href="css/style.css">
</head>

<body>

	<!--================ Start Header Area =================-->
	<?php include 'navbar.php'; ?>
	<!--================ End Header Area =================-->

    <!--================ Start Banner Area =================-->
    <section class="banner_area">
        <div class="banner_inner d-flex align-items-center">
            <div class="container">
                <div class="banner_content text-center">
                    <h2>About Me</h2>
                    <div class="page_link">
                        <a href="index.html">Home</a>
                        <a href="about.html">About</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--================ End Banner Area =================-->
    
   <!--================ Start About Us Area =================-->
   <section class="about_area section_gap">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="main_title text-center">
                        <h2>Biodata</h2>
                        <p>Halo! Saya seorang mahasiswa yang antusias dengan minat dalam pengembangan website, fotografi, dan desain UI. Saya juga berperan aktif dalam organisasi kampus dan sedang belajar untuk meningkatkan keterampilan saya di bidang teknologi. Berikut ini adalah informasi lebih lanjut tentang saya.</p>
                    </div>
                    <table class="table table-bordered table-striped">
                        <tbody>
                            <tr>
                                <th scope="row">Nama</th>
                                <td><?php echo $biodata['nama']; ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Tempat, Tanggal Lahir</th>
                                <td><?php echo $biodata['tempat_tanggal_lahir']; ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Program Studi</th>
                                <td><?php echo $biodata['program_studi']; ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Semester</th>
                                <td><?php echo $biodata['semester']; ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Universitas</th>
                                <td><?php echo $biodata['universitas']; ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Hobi</th>
                                <td><?php echo $biodata['hobi']; ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Posisi di Organisasi</th>
                                <td><?php echo $biodata['posisi_organisasi']; ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Keahlian Utama</th>
                                <td><?php echo $biodata['keahlian_utama']; ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
    <!--================ End About Us Area =================-->

    <!--================Footer Area =================-->
	<?php include 'footer.php'; ?>
    <!--================End Footer Area =================-->
    
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/stellar.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="vendors/nice-select/js/jquery.nice-select.min.js"></script>
    <script src="vendors/isotope/imagesloaded.pkgd.min.js"></script>
    <script src="vendors/isotope/isotope-min.js"></script>
    <script src="vendors/owl-carousel/owl.carousel.min.js"></script>
    <script src="js/jquery.ajaxchimp.min.js"></script>
    <script src="js/mail-script.js"></script>
    <!--gmaps Js-->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCjCGmQ0Uq4exrzdcL6rvxywDDOvfAu6eE"></script>
    <script src="js/gmaps.min.js"></script>
    <script src="js/theme.js"></script>
</body>

</html>
