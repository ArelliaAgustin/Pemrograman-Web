<!doctype html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Hobi Saya</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="vendors/linericon/style.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="vendors/nice-select/css/nice-select.css">
    <!-- Main CSS -->
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <!--================ Start Header Area =================-->
    <?php include 'navbar.php'; ?>
    <!--================ End Header Area =================-->

    <!-- Banner -->
    <section class="banner_area">
        <div class="banner_inner d-flex align-items-center">
            <div class="container">
                <div class="banner_content text-center">
                    <h2>My Hobbies</h2>
                    <div class="page_link">
                        <a href="index.html">Home</a>
                        <a href="hobbies.php">Hobbies</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Menampilkan Hobi -->
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="main_title text-center">
                <h2>My Hobbies</h2>
                <p>Saya memiliki beberapa hobi diantaranya:</p>
            </div>
            <div class="row text-center">
                <?php
                include 'koneksi.php';
                $sql = "SELECT * FROM hobbies";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo '<div class="col-md-4">';
                        echo '    <div class="hobby-box">';
                        echo '        <img src="img/hobbies/' . htmlspecialchars($row['image']) . '" class="img-fluid rounded-circle mb-3" alt="' . htmlspecialchars($row['name']) . '" width="150">';
                        echo '        <h5>' . htmlspecialchars($row['name']) . '</h5>';
                        echo '        <p>' . htmlspecialchars($row['description']) . '</p>';
                        echo '    </div>';
                        echo '</div>';
                    }
                } else {
                    echo "<p>Tidak ada hobi yang ditemukan.</p>";
                }

                $conn->close();
                ?>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php include 'footer.php'; ?>

    <!-- JavaScript Files -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/stellar.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="vendors/nice-select/js/jquery.nice-select.min.js"></script>
    <script src="vendors/isotope/imagesloaded.pkgd.min.js"></script>
    <script src="vendors/isotope/isotope-min.js"></script>
    <script src="vendors/owl-carousel/owl.carousel.min.js"></script>
    <script src="js/theme.js"></script>
</body>

</html>