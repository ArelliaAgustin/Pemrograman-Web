<?php
// skills.php

include 'koneksi.php';

// Query untuk mengambil data keterampilan
$sql = "SELECT * FROM skills";
$result = $conn->query($sql);
?>

<!doctype html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Keterampilan Saya</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="vendors/linericon/style.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="vendors/nice-select/css/nice-select.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <!--================ Start Header Area =================-->
    <?php include 'navbar.php'; ?>
    <!--================ End Header Area =================-->

    <!--================ Start Banner Area =================-->
    <section class="banner_area">
        <div class="banner_inner d-flex align-items-center">
            <div class="container">
                <div class="banner_content text-center">
                    <h2>My Skills</h2>
                    <div class="page_link">
                        <a href="index.html">Home</a>
                        <a href="skills.php">Skills</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--================ End Banner Area =================-->

    <!--================ Start Features Area =================-->
    <section class="features_area section_gap_top">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8 text-center">
                    <div class="main_title">
                        <h2>My Skills</h2>
                        <p>Berikut adalah beberapa skills yang saya kuasai:</p>
                    </div>
                </div>
            </div>
            <div class="row feature_inner">
                <?php
                if ($result && $result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo '<div class="col-lg-3 col-md-6">';
                        echo '<div class="feature_item">';
                        echo '<img src="img/skills/' . $row['image'] . '" alt="">';
                        echo '<h4>' . $row['skill_name'] . '</h4>';
                        echo '<p>' . $row['description'] . '</p>';
                        echo '</div>';
                        echo '</div>';
                    }
                } else {
                    echo "<p>Tidak ada keterampilan yang ditemukan.</p>";
                }

                // Tutup koneksi setelah seluruh operasi selesai
                $conn->close();
                ?>
            </div>
        </div>
    </section>
    <!--================ End Features Area =================-->

    <!--================ Footer Area =================-->
    <?php include 'footer.php'; ?>
    <!--================ End Footer Area =================-->

    <!-- Optional JavaScript -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/stellar.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="vendors/nice-select/js/jquery.nice-select.min.js"></script>
    <script src="vendors/owl-carousel/owl.carousel.min.js"></script>
    <script src="js/theme.js"></script>
</body>

</html>
