<?php
// koneksi.php
// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_utspemweb";

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Query untuk mengambil data biodata
$sqlBiodata = "SELECT * FROM biodata WHERE id = 1";
$resultBiodata = $conn->query($sqlBiodata);

if ($resultBiodata && $resultBiodata->num_rows > 0) {
    $biodata = $resultBiodata->fetch_assoc();
} else {
    $biodata = null;
}

// Query untuk mengambil data pengguna
$sqlUsers = "SELECT * FROM users WHERE id = 1";
$resultUsers = $conn->query($sqlUsers);

if ($resultUsers && $resultUsers->num_rows > 0) {
    $users = $resultUsers->fetch_assoc();
} else {
    $users = null;
}

// Query untuk mengambil data skills
$sqlSkills = "SELECT * FROM skills WHERE id = 1";
$resultSkills = $conn->query($sqlSkills);

if ($resultSkills && $resultSkills->num_rows > 0) {
    $skills = $resultSkills->fetch_assoc();
} else {
    $skills = null;
}
?>
