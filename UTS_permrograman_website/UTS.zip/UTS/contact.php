<!doctype html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="img/favicon2.png" type="image/png">
    <title>Contact Us</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="vendors/linericon/style.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="vendors/nice-select/css/nice-select.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        .contact_info {
            display: flex;
            flex-direction: column;
            margin-bottom: 15px;
        }

        .contact_info .info_item {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }

        .contact_info .info_item span {
            font-size: 24px;
            margin-right: 10px;
        }

        .form-container {
            display: flex;
            flex-wrap: wrap;
        }

        .form-container .form-group {
            width: 100%;
            margin-bottom: 15px;
        }

        .contact_map {
            width: 100%;
            margin-top: 20px;
        }
    </style>
</head>

<body>
    <!--================ Start Header Area =================-->
    <?php include 'navbar.php'; ?>
    <!--================ End Header Area =================-->

    <!--================ Start Banner Area =================-->
    <section class="banner_area">
        <div class="banner_inner d-flex align-items-center">
            <div class="container">
                <div class="banner_content text-center">
                    <h2>My Contact</h2>
                    <div class="page_link">
                        <a href="index.html">Home</a>
                        <a href="contact.php">Contact</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--================ End Banner Area =================-->

    <!--================ Start Contact Area =================-->
    <section class="contact_area section_gap">
        <div class="main_title text-center">
            <h2>Hubungi Saya</h2>
            <p>Anda dapat menghubungi saya melalui email atau nomor telepon di bawah ini, atau mengisi form di bawah ini:</p>
        </div>
        <div class="container">
            <div class="form-container">
                <div class="col-lg-6">
                    <div class="contact_info">
                        <div class="info_item">
                            <span class="lnr lnr-envelope"></span>
                            <h6>arellgstn24@gmail.com</h6>
                        </div>
                        <div class="info_item">
                            <span class="lnr lnr-phone-handset"></span>
                            <h6>085894751675</h6>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <form class="contact_form" action="contact_process.php" method="post" id="contactForm">
                        <div class="form-group">
                            <label for="name">Nama:</label>
                            <input type="text" class="form-control" id="name" name="name" placeholder="Masukkan nama Anda" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Masukkan alamat email" required>
                        </div>
                        <div class="form-group">
                            <label for="subject">Subject:</label>
                            <input type="text" class="form-control" id="subject" name="subject" placeholder="Masukkan subjek pesan" required>
                        </div>
                        <div class="form-group">
                            <label for="message">Message:</label>
                            <textarea class="form-control" name="message" id="message" rows="6" placeholder="Masukkan pesan Anda" required></textarea>
                        </div>
                        <div class="text-right">
                            <button type="submit" class="btn btn-primary">
                                <span>Send Message</span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="contact_map">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.781438323509!2d106.72287607455688!3d-6.292430293696598!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f007dedc7de1%3A0x70288cde58f42a97!2sPembangunan%20Jaya%20University!5e0!3m2!1sen!2sid!4v1719996441147!5m2!1sen!2sid" width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>
    </section>
    <!--================ End Contact Area =================-->

    <!--================ Footer Area =================-->
    <?php include 'footer.php'; ?>
    <!--================ End Footer Area =================-->

    <!-- Optional JavaScript -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/stellar.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="vendors/nice-select/js/jquery.nice-select.min.js"></script>
    <script src="vendors/owl-carousel/owl.carousel.min.js"></script>
    <script src="js/theme.js"></script>
</body>

</html>
